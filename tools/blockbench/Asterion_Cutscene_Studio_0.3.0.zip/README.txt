Asterion Cutscene Studio 0.3.0

Install in Blockbench
1. Open Blockbench 4.12 or newer.
2. Go to File > Plugins > Load Plugin from File.
3. Select asterion_cutscene.js from this folder.
4. Create a scene through File > New > Minecraft > Cutscene.

This is a standalone Blockbench plugin. The recipient does not need this source repository.

Open cutscene_demo.bbmodel to see an example actor, animation, and camera setup.

For Minecraft playback, the recipient also needs a matching Asterion mod build. The plugin can still create and export cutscene files without the mod installed.

The full feature guide is included as CUTSCENE_STUDIO_GUIDE.md.
