# Asterion Cutscene Studio — preview 0.2.4

A visual Blockbench editor with local cutscene playback in Asterion for Minecraft 26.1.2. Load **asterion_cutscene.js** through Blockbench’s **Plugins → Load Plugin from File**. Reload the plugin if an older copy is already loaded. Keep the plugin installed when saving scene projects.

## Start a scene

Choose **File → New → Minecraft → Cutscene** (or **File → Cutscene: New Scene**). The **Cutscene** mode appears beside Blockbench’s other modes. Its Studio panel has Director, Actors, World and Clips tabs. Use **Save scene** to save your editable work as `.bbmodel`, including the embedded schematic/reference block data, placement, actors and textures. Reopening that project does not require the original schematic file; **Export for Asterion** creates the separate baked playback file.

Open `cutscene_demo.bbmodel` for an example camera path and waving actor. Select `animation.demo.wave` in Animate, then return to Cutscene.

## Director: camera controls

- **Pilot camera** puts the viewport at the current shot and allows ordinary viewport movement/orbiting. **Camera preview** follows the timeline. Click either again to return to the previous editor view. Split Screen lets you watch the camera and its path from a second viewport.
- **Forward / Back / Left / Right / Up / Down** move the camera and its target together. The movement-step slider sets the distance in blocks. Click **Capture view** to save the resulting shot at the playhead.
- **Manual pose at playhead** makes a camera keyframe with exact time, position, look-at point, FOV, roll and interpolation fields. **Duplicate pose here** copies the selected pose, or the current interpolated pose, to the playhead. These controls are in the Director tab and only affect the camera; they do not create model-animation keys.
- Select a camera key to open position and look-at sliders, numeric position inputs, vertical FOV and roll sliders, and interpolation controls. Sliders preview while dragging and commit on release. Numeric position fields accept values beyond the slider’s ±64-block range. **Edit** also changes key time.
- **Record movement** samples camera movement at 20 keys/second while the scene advances. Move the pilot viewport or use the movement buttons. Stop to keep the take; **Discard** restores the prior path. A take replaces keys only within its recorded interval. Recording captures position, view direction and FOV with zero roll; authored keys can add roll afterward.
- **Aim at actor** sets a look-at point at the chosen actor’s current bounds. This is a captured target, not a live tracking constraint. **Orbit shot** generates a sampled orbit around a chosen point with radius, height, angle, duration and key-count controls.
- **Move with gizmo** creates a temporary selected marker in the Outliner. Move it with Blockbench’s normal move gizmo, then click **Apply gizmo**. For camera keys, the camera and its target translate together. For schematic/world placement, it changes the reference position. **Discard gizmo** removes the marker without changing the scene.
- **Guides**, **Path**, **Frustum** and **Look line** toggle independently. Green markers identify camera keys; the green line shows the path and amber shows the viewing direction. **Hold → hard cut** keeps a shot until the next key.
- Play/pause and the time slider work in Cutscene mode. Scene settings control duration, sample rate, aspect reference, fullbright actors and guide visibility.

Long scenes keep all authored camera keys, but camera interpolation uses binary search and the viewport guide line is automatically reduced to at most 2,000 display points so recording a long take stays responsive. Export still preserves every key. Schematic meshing uses compact numeric cell lookups and only creates visible merged surfaces. The actor bake budget remains 500,000 object samples: a one-hour export generally needs 20 FPS and one moving actor, or separate chapter files.

Camera/settings edits have a separate **Tools → Cutscene: Undo Camera / Settings Edit** history, bounded to 20 entries and approximately 8 MB (one large snapshot may exceed that budget). Model and texture edits use Blockbench’s regular Undo.

## Actors and animation

**Add Player** creates classic or slim arms and six animatable body parts. Optional hat, jacket, sleeve and trouser overlays share their parent bones. New rigs use the corrected left/right limb mapping. Existing player cards offer **Fix limb sides**, which corrects limb names and UVs without moving their geometry or changing animation identifiers. **Skin PNG** reads PNG bytes directly on desktop and accepts a modern 64×64 skin; edit it in Blockbench Paint mode. **Layers** toggles the outer layer geometry. The placeholder skin has transparent overlay areas, so supply or paint an overlay to see those layers. This uses an authored skin; automatic account-skin lookup is not included.

**Import model** accepts `.bbmodel` files with embedded textures and rigid cube/mesh geometry, or Bedrock/GeckoLib `.geo.json` cube geometry. Imports receive separate bone/animation identifiers and textures. A `.geo.json` does not contain its texture; select the matching PNG when prompted. Use **Animation JSON** on an actor to import matching Bedrock/GeckoLib bone animation channels by bone name. Duplicate or missing bone names are reported. Geometry alone does not include animations.

**Select / move** selects the actor in Edit mode for normal transform tools. **Position** provides exact placement in blocks and root rotation. **Remove** deletes an actor/import from the editable scene; Blockbench Undo restores it. **Reference only** excludes a model from the baked runtime export while retaining it as editable scene geometry. Use this for detailed textured scenery exported to `.bbmodel` by another tool.

**Animate bones** opens Blockbench’s native animation editor. With no scheduled clips, the active native animation selection determines the pose. In the Clips tab, schedule imported or authored animations with scene start/end times, source offset, speed and looping. Clips can overlap and combine; crossfades are not implemented. Deleted source animations must be replaced or removed from the schedule before export.

## Bring a Minecraft location into Blockbench

In the Asterion client, stand near the scene and run:

```
/cutscene reference courtyard 16
```

This saves `cutscenes/courtyard.reference.json` in the Minecraft instance directory. In **World → Import world / schematic**, select that file. World coordinates are retained and playback is anchored to the captured region’s minimum corner. Radius is 1–24 blocks: the captured cube has side length `2 × radius + 1`. The command only reads already loaded client chunks, never generates chunks, and will not overwrite an existing file; use a new name for another capture.

This is a direct export from the running Minecraft world followed by a file import. It is not a live connection or a saved-world-folder importer. Regions are intentionally bounded. Capture additional regions as separate reference files when needed; the panel holds one optimized reference at a time.

Other supported references:

| Input | Support |
| --- | --- |
| Sponge `.schem` | v2 and v3 palette storage |
| MCEdit `.schematic` | Legacy numeric block IDs |
| Java structure `.nbt` | Palette and block-list layout |
| Blueprint PNG | Ground plan or vertical elevation, sized in blocks |
| Detailed textured `.bbmodel` | Import as an actor, then enable Reference only |

Gzip-compressed and uncompressed Java NBT are accepted. `.mca` region files, world folders and `.litematic` are not currently supported.

Terrain references use colored full-block proxies. Hidden faces are removed and adjacent surfaces of the same block palette entry are merged. They preserve block positions and overall volume, but do not reproduce stairs, slabs, plants, block entities, fluids, resource-pack models or textures accurately. Reference meshes and blueprint images are never baked as runtime actors; the existing Minecraft terrain supplies the actual scenery.

Imported structures are centered on their occupied X/Z bounds and placed with their bottom at ground level, ignoring empty selection padding. **Center structure** applies this placement to an existing reference. **Position / align** changes the reference translation, yaw, opacity, visibility and playback world origin. The six nudge buttons move it by one block; **Frame world** fits it in the viewport. For an Asterion world capture with world anchoring enabled, export transforms the camera and actors back from the moved/rotated reference into the captured world coordinates. The world-origin field is the captured corner, or your chosen replacement corner. Imported schematics and blueprints without a captured world origin use scene coordinates directly; set their playback origin manually.

## Playback

Copy the exported `name.cutscene.json` into the instance’s `cutscenes` directory and run `/cutscene play name`. Use the Asterion build containing Cutscene Studio. The command reports the expected directory if the file is missing.

| Command | Result |
| --- | --- |
| `/cutscene play name` | Play at the exported world origin, or the player’s feet if world anchoring is disabled. |
| `/cutscene pause` / `/cutscene resume` | Pause or continue. |
| `/cutscene seek 2.5` | Seek and pause. |
| `/cutscene origin 100 64 -20` | Override the active playback origin. |
| `/cutscene stop` | Restore camera/controls and release scene textures. |

Actors are local visual copies. They do not move server entities, have collision, or synchronize with other players. Playback hides the HUD and held item and stops at the end, on world changes, or when the pause screen is observed. Camera movement does not load distant terrain; stay within the player’s loaded region.

## Compatibility and precision

One block equals 16 Blockbench units. Camera position, target, FOV and roll use matching JavaScript/Java interpolation. Actor geometry, textures and sampled world matrices are embedded in the export. Full affine matrices retain bone pivots, scales and shear at sample times. Between samples, matrices interpolate linearly, so rapid rotations can produce slight scale changes; use 60 or 120 Hz for demanding motion.

GeckoLib compatibility is baked visual playback, not live GeckoLib controller execution. The Cutscene workspace keeps Blockbench cube/mesh projects and enables common edit-time elements such as billboards, splines, armatures, texture meshes, animated textures and animation controllers, so imports from other plugins stay editable when Blockbench supports them. Standard bone clips can be imported. Custom GeckoLib easing must be exported from its original GeckoLib Animated Model project with the GeckoLib plugin installed, or baked to standard keys before importing into the Cutscene format. The importer rejects unsupported easing instead of silently losing it. Game-dependent Molang expressions use their editor preview values. Controllers, deforming armatures, billboards, animated textures, sound/particle/event transport, PBR and emissive effects are outside this preview’s playback support.

Use matching editor/game aspect ratios when comparing framing. The reference frustum uses the scene aspect, while the actual viewport/game use their window sizes; automatic letterboxing is not included. Lighting and shaders may differ. A camera target must stay separated from its position along the path.

Scene limits: 3,600 seconds (one hour), 500,000 object samples, 64 MB playback JSON, 256 textures, 4,096 pixels per image edge, 32 million decoded pixels and one million triangle vertices. Reference limits: 64 MB decoded NBT, 16,777,216 selection cells (including air), two million unique non-air blocks for import memory, four million exposed faces before merging, and 250,000 visible quads after merging. Empty selection padding does not count as solid geometry. The importer validates and optimizes the new mesh before replacing the current reference, and reports actual decoded counts when a limit is reached.

## Share the plugin

Send [Asterion_Cutscene_Studio_0.3.0.zip](Asterion_Cutscene_Studio_0.3.0.zip) to another creator. They extract it and load `asterion_cutscene.js` with **File → Plugins → Load Plugin from File**. The ZIP contains the standalone plugin, guide and demo. Minecraft playback also requires a matching Asterion mod build.

## Development and checks

Edit `src/core.js` and `src/plugin.js`, then run `node tools/blockbench/build.cjs` to regenerate the standalone plugin. `create-demo.cjs` regenerates the editable sample. `node tools/blockbench/reference.test.cjs [schematic-path]` checks padded 60-block selections, dense terrain optimization and optional real schematic files.

The Node harness exercises the actual plugin with real Three.js geometry: camera export, scale, error restoration, pilot controls, recording cancellation, inspector edits, toggles, cleanup, NBT parsing, schematic normalization, greedy meshing, UUID isolation and animation conversion. When the Vue compiler is available it also compiles the panel and renders all four tabs. The Java smoke test compares 81 camera samples with JavaScript and checks actor interpolation and world-origin validation. Fabric and NeoForge compilation passed. The expanded 0.2 UI and world-export command still need a live application/game acceptance pass.

Reference APIs: [Blockbench source](https://github.com/JannisX11/blockbench), [plugin guide](https://www.blockbench.net/wiki/docs/plugin/), [GeckoLib plugin](https://github.com/JannisX11/blockbench-plugins/tree/master/plugins/geckolib).
